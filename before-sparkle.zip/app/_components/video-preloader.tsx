"use client";

import { useEffect, useRef } from "react";
import { gsap } from "gsap";

interface VideoPreloaderProps {
  progress: number;
  isComplete: boolean;
  onAnimationComplete: () => void;
}

export default function VideoPreloader({
  progress,
  isComplete,
  onAnimationComplete,
}: VideoPreloaderProps) {
  const preloaderRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    // Animate progress number
    if (progressRef.current) {
      gsap.to(progressRef.current, {
        textContent: Math.round(progress),
        duration: 0.5,
        ease: "power2.out",
        snap: { textContent: 1 },
      });
    }
  }, [progress]);

  useEffect(() => {
    if (isComplete && preloaderRef.current) {
      // Reveal animation - slide up and off screen
      const tl = gsap.timeline({
        onComplete: onAnimationComplete,
      });

      tl.to(preloaderRef.current, {
        y: "-100%",
        duration: 1.2,
        ease: "power2.inOut",
      });
    }
  }, [isComplete, onAnimationComplete]);

  return (
    <div
      ref={preloaderRef}
      className="fixed inset-0 z-50 bg-background flex items-center justify-center"
    >
      <div className="text-center">
        {/* Loading percentage */}
        <div className="mb-8">
          <span
            ref={progressRef}
            className="font-fjalla-one text-6xl md:text-8xl text-foreground"
          >
            0
          </span>
          <span className="font-fjalla-one text-6xl md:text-8xl text-foreground">
            %
          </span>
        </div>

        {/* Loading text */}
        <div className="font-libre-baskerville text-sm md:text-base text-foreground/60 tracking-wider uppercase">
          Loading Showreel
        </div>

        {/* Progress bar (optional visual indicator) */}
        <div className="mt-8 w-64 h-px bg-foreground/20 mx-auto">
          <div
            className="h-full bg-foreground transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}
