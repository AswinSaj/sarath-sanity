"use client";

import { useState, useEffect } from "react";
import { client } from "@/sanity/lib/client";
import { allPoemsQuery } from "@/sanity/lib/queries";
import { StickyScroll } from "@/components/ui/sticky-scroll-reveal";
import { PortableText } from "@portabletext/react";
import Image from "next/image";
import Link from "next/link";

interface Poem {
    _id: string;
    title: string;
    photo?: {
        asset: {
            _id: string;
            url: string;
        };
        alt?: string;
    };
    content: any[];
}

async function getAllPoems(): Promise<Poem[]> {
    try {
        const data = await client.fetch(allPoemsQuery);
        return data;
    } catch (error) {
        console.error("Error fetching poems:", error);
        return [];
    }
}

export default function TestPoemPage() {
    const [poems, setPoems] = useState<Poem[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchPoems() {
            const data = await getAllPoems();
            setPoems(data);
            setLoading(false);
        }
        fetchPoems();
    }, []);

    if (loading) {
        return (
            <div className="min-h-screen bg-black text-white flex items-center justify-center">
                <div className="text-center">
                    <h1 className="text-4xl font-bold mb-4">Loading Poems...</h1>
                </div>
            </div>
        );
    }

    if (poems.length === 0) {
        return (
            <div className="min-h-screen bg-black text-white flex items-center justify-center">
                <div className="text-center">
                    <h1 className="text-4xl font-bold mb-4">No Poems Found</h1>
                    <p className="text-gray-400">Please add some poems in Sanity CMS</p>
                </div>
            </div>
        );
    }

    // Transform poems data to match StickyScroll content format
    const stickyScrollContent = poems.map((poem) => ({
        title: poem.title,
        description: (
            <div className="text-gray-300 leading-relaxed text-center">
                <PortableText
                    value={poem.content}
                    components={{
                        block: {
                            normal: ({ children }) => (
                                <div className="mb-4 leading-relaxed text-base">{children}</div>
                            ),
                        },
                        marks: {
                            strong: ({ children }) => (
                                <strong className="font-bold text-white">{children}</strong>
                            ),
                            em: ({ children }) => (
                                <em className="italic text-gray-200">{children}</em>
                            ),
                        },
                    }}
                />
            </div>
        ),
        content: (
            <div className="flex h-full w-full">
                {poem.photo ? (
                    <div className="relative w-full h-full">
                        <Image
                            src={poem.photo.asset.url}
                            alt={poem.photo.alt || poem.title}
                            fill
                            className="object-cover"
                            sizes="50vw"
                        />
                        {/* Overlay with only poem title */}
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center p-8">
                            <div className="text-center text-white">
                                <h3 className="text-3xl lg:text-4xl font-bold">{poem.title}</h3>
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="flex h-full w-full items-center justify-center bg-black text-white">
                        <div className="text-center p-8 max-w-lg mx-auto">
                            <h3 className="text-3xl font-bold mb-6">{poem.title}</h3>
                            <div className="text-gray-300 leading-relaxed text-center">
                                <PortableText
                                    value={poem.content}
                                    components={{
                                        block: {
                                            normal: ({ children }) => (
                                                <div className="mb-4 leading-relaxed text-base">{children}</div>
                                            ),
                                        },
                                        marks: {
                                            strong: ({ children }) => (
                                                <strong className="font-bold text-white">{children}</strong>
                                            ),
                                            em: ({ children }) => (
                                                <em className="italic text-gray-200">{children}</em>
                                            ),
                                        },
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                )}
            </div>
        ),
    }));

    return (
        <div className="min-h-screen bg-black">
            {/* Back Button */}
            <div className="absolute top-6 left-6 z-50">
                <Link
                    href="/"
                    className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-lg text-white transition-all duration-300 hover:scale-105"
                >
                    <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10 19l-7-7m0 0l7-7m-7 7h18"
                        />
                    </svg>
                    Back to Home
                </Link>
            </div>

            {/* Header */}
            <div className="text-center py-20 px-6">
                <h1 className="text-5xl font-bold text-white mb-4 tracking-wider">
                    POETRY TEST
                </h1>
                <p className="text-gray-400 text-lg">
                    Testing Sticky Scroll with Poems from Sanity
                </p>
            </div>

            {/* Sticky Scroll Component */}
            <div className="w-full">
                <StickyScroll content={stickyScrollContent} />
            </div>
        </div>
    );
}