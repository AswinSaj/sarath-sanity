export const links = [
  { title: 'About', href: '/#about' },
  {
    title: 'Photography',
    href: '/#photography',
  },
  {
    title: 'Filmography',
    href: '/#filmography',
  },
  {
    title: 'Poetry',
    href: '/poem',
  },
  {
    title: 'Contact',
    href: '/#contact',
  },
]