import React from 'react'

const Logo = () => {
  return (
    <div className="w-16 h-16 md:w-20 md:h-20 flex items-center justify-center">
      <div className="text-2xl md:text-3xl font-bold text-white">
        SM
      </div>
    </div>
  )
}

export default Logo