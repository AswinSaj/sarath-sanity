import { client } from "@/sanity/lib/client";
import { allPoemsQuery } from "@/sanity/lib/queries";
import { PortableText } from "@portabletext/react";
import Image from "next/image";
import Link from "next/link";

interface Poem {
  _id: string;
  title: string;
  photo?: {
    asset: {
      _id: string;
      url: string;
    };
    alt?: string;
  };
  content: any[];
}

async function getAllPoems(): Promise<Poem[]> {
  try {
    const data = await client.fetch(allPoemsQuery);
    return data;
  } catch (error) {
    console.error("Error fetching poems:", error);
    return [];
  }
}

export default async function PoemsPage() {
  const poems = await getAllPoems();

  return (
    <div className="min-h-screen bg-black text-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header with Back Button */}
        <div className="mb-16">
          <Link 
            href="/#poetry" 
            className="inline-flex items-center text-gray-400 hover:text-white transition-colors duration-300 mb-8"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Poetry
          </Link>
          
          <h1 className="text-4xl sm:text-5xl font-bold tracking-wider mb-4 text-center">POETRY</h1>
          <p className="text-gray-300 text-lg max-w-3xl text-center mx-auto">
            Explore Sarath's inner world through his collection of poems that reflect the depth at which he exists.
          </p>
        </div>

        {/* Poems List */}
        {poems.length > 0 ? (
          <div className="space-y-24 lg:space-y-32">
            {poems.map((poem, index) => (
              <article key={poem._id} className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-start">
                {/* Image Section */}
                <div className={`${index % 2 === 1 ? 'lg:order-2' : 'lg:order-1'}`}>
                  <div className="relative aspect-square rounded-lg overflow-hidden bg-gray-200">
                    {poem.photo ? (
                      <Image
                        src={poem.photo.asset.url}
                        alt={poem.photo.alt || poem.title}
                        fill
                        className="object-cover"
                        sizes="(max-width: 1024px) 100vw, 50vw"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                        <div className="text-gray-400 text-center">
                          <svg className="w-16 h-16 mx-auto mb-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
                          </svg>
                          <p className="text-sm">No Image</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Content Section */}
                <div className={`flex flex-col justify-center ${index % 2 === 1 ? 'lg:order-1' : 'lg:order-2'}`}>
                  <div className="space-y-6 text-center lg:text-left">
                    <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold leading-tight">
                      {poem.title}
                    </h2>
                    
                    <div className="poem-content">
                      <PortableText
                        value={poem.content}
                        components={{
                          block: {
                            normal: ({ children }) => (
                              <div className="text-gray-300 leading-snug mb-3 text-base sm:text-lg whitespace-pre-line">
                                {children}
                              </div>
                            ),
                            h1: ({ children }) => (
                              <h1 className="text-2xl sm:text-3xl font-bold mb-4 leading-tight">{children}</h1>
                            ),
                            h2: ({ children }) => (
                              <h2 className="text-xl sm:text-2xl font-bold mb-4 leading-tight">{children}</h2>
                            ),
                            h3: ({ children }) => (
                              <h3 className="text-lg sm:text-xl font-bold mb-4 leading-tight">{children}</h3>
                            ),
                            blockquote: ({ children }) => (
                              <blockquote className="border-l-4 border-white pl-6 italic text-lg sm:text-xl mb-6 text-gray-200 leading-relaxed text-left">
                                {children}
                              </blockquote>
                            ),
                          },
                          marks: {
                            strong: ({ children }) => (
                              <strong className="font-bold text-white">{children}</strong>
                            ),
                            em: ({ children }) => (
                              <em className="italic text-gray-200">{children}</em>
                            ),
                          },
                        }}
                      />
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-gray-400 mb-4">
              <svg className="w-24 h-24 mx-auto mb-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold mb-2">No Poems Yet</h3>
            <p className="text-gray-400">
              Poems haven't been published yet. Check back soon for Sarath's poetry collection.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}