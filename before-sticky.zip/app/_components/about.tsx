import { client } from "@/sanity/lib/client";
import { aboutQuery } from "@/sanity/lib/queries";

interface AboutData {
  _id: string;
  description: string;
}

async function getAboutData(): Promise<AboutData | null> {
  try {
    const data = await client.fetch(aboutQuery);
    return data;
  } catch (error) {
    console.error("Error fetching about data:", error);
    return null;
  }
}

export default async function About() {
  const aboutData = await getAboutData();

  return (
    <section className="min-h-screen bg-black text-white py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Fixed Header */}
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold mb-8 tracking-wider">ABOUT</h2>
        </div>

        {/* Description Box */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="text-lg text-gray-300 leading-relaxed space-y-6">
            {aboutData?.description ? (
              aboutData.description.split('\n\n').map((paragraph, index) => (
                <p key={index} className="text-lg text-gray-300 leading-relaxed">
                  {paragraph.trim()}
                </p>
              ))
            ) : (
              <p className="text-lg text-gray-300 leading-relaxed">
                Content not available
              </p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}